const submit_btn = document.querySelector(".submit_btn");

submit_btn.onclick = ()=>{
    var pem = document.querySelector(.pesan);
    var nile = document.querySelector(.nilai);
    if (nile >= 90){
        document.getElementsByClassName(pesan).innerHTML() = "Kamu lulus";
    }
}

    // function submit_btn(){
    //     var textpem;
    //     var pem = nilai.value;
    //     if (pem >= 90){
    //         textpem = "Kamu Lulus";
    //         document.getElementById("pesan").innerHTML = textpem;
    //     }
    // }
